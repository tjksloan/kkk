import Link from "next/link"
import { ArrowRight, CheckCircle2, Target, Database, Zap } from 'lucide-react'

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function Component() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-16 flex items-center">
        <Link className="flex items-center justify-center" href="#">
          <span className="font-bold text-2xl">OutboundIntel</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Features
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Pricing
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            About
          </Link>
          <Button>Get Started</Button>
        </nav>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-gradient-to-r from-blue-50 via-purple-50 to-pink-50">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                    Stop Wasting Time on Unqualified Leads
                  </h1>
                  <p className="max-w-[600px] text-gray-500 md:text-xl">
                    Turn your cold email campaigns into precision-targeted missions with intent-based audience intelligence.
                  </p>
                </div>
                <div className="space-y-2">
                  <h2 className="text-xl font-bold">The Cold Email Agency&apos;s Biggest Challenge</h2>
                  <p className="text-gray-500">
                    You know the drill. Hours spent building lists. Generic data that barely scratches the surface. Campaigns
                    that deliver lukewarm results. Your clients deserve better, and so do you.
                  </p>
                </div>
                <div className="flex flex-col gap-2">
                  <Button size="lg" className="w-fit">
                    Start Your Trial
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="relative w-full h-full min-h-[300px]">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg opacity-10" />
                  <div className="relative p-6">
                    <div className="grid gap-4 md:gap-8">
                      <div className="flex items-center gap-4">
                        <CheckCircle2 className="h-6 w-6 text-green-500" />
                        <p className="text-lg">Cut list-building time by 80%</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <CheckCircle2 className="h-6 w-6 text-green-500" />
                        <p className="text-lg">Double your client&apos;s conversion rates</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <CheckCircle2 className="h-6 w-6 text-green-500" />
                        <p className="text-lg">Access deep personalization data</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <CheckCircle2 className="h-6 w-6 text-green-500" />
                        <p className="text-lg">Deliver campaigns that make clients say "wow"</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">The OutboundIntel Difference</h2>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Your secret weapon for high-converting cold email campaigns. We don&apos;t just build lists – we engineer
                  success through intent-based audience intelligence.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3 lg:gap-12">
              <Card>
                <CardHeader>
                  <Target className="h-10 w-10 mb-4 text-primary" />
                  <CardTitle>Custom Intent Signals</CardTitle>
                </CardHeader>
                <CardContent>
                  Stop guessing who&apos;s ready to buy. Our proprietary intelligence identifies prospects at the perfect
                  moment.
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <Database className="h-10 w-10 mb-4 text-primary" />
                  <CardTitle>Deep Personalization Variables</CardTitle>
                </CardHeader>
                <CardContent>
                  Go beyond FirstName. Access custom variables that make every email feel personally crafted.
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <Zap className="h-10 w-10 mb-4 text-primary" />
                  <CardTitle>Triple-Verified Data</CardTitle>
                </CardHeader>
                <CardContent>
                  Every lead is verified through our 3-step process. Say goodbye to bounces and hello to inbox placement.
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Choose Your Power Level</h2>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Whether you&apos;re handling 10,000 or 50,000 leads per month, we&apos;ve got you covered with plans that
                  scale with your success.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle>Starter</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">$99</div>
                  <div className="text-sm text-gray-500">per month</div>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center">
                      <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
                      10,000 verified leads
                    </li>
                    <li className="flex items-center">
                      <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
                      Custom intent signals
                    </li>
                    <li className="flex items-center">
                      <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
                      Basic personalization variables
                    </li>
                  </ul>
                  <Button className="mt-6 w-full">Get Started</Button>
                </CardContent>
              </Card>
              <Card className="border-primary">
                <CardHeader>
                  <CardTitle>Growth</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">$299</div>
                  <div className="text-sm text-gray-500">per month</div>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center">
                      <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
                      20,000 verified leads
                    </li>
                    <li className="flex items-center">
                      <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
                      Advanced intent tracking
                    </li>
                    <li className="flex items-center">
                      <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
                      Extended personalization suite
                    </li>
                  </ul>
                  <Button className="mt-6 w-full">Get Started</Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Agency</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">$599</div>
                  <div className="text-sm text-gray-500">per month</div>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center">
                      <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
                      50,000 verified leads
                    </li>
                    <li className="flex items-center">
                      <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
                      Premium intent intelligence
                    </li>
                    <li className="flex items-center">
                      <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
                      Full personalization arsenal
                    </li>
                  </ul>
                  <Button className="mt-6 w-full">Get Started</Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Ready to Transform Your Cold Email Campaigns?</h2>
                  <p className="max-w-[600px] text-gray-500 md:text-xl">
                    Let&apos;s discuss how OutboundIntel can supercharge your agency&apos;s outreach.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button size="lg">
                    Book Your Strategy Call
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="lg">
                    Start Your Trial
                  </Button>
                </div>
              </div>
              <div className="flex flex-col space-y-4 lg:justify-center">
                <div className="grid gap-4">
                  <div className="flex items-center gap-4">
                    <div className="text-4xl font-bold">95%</div>
                    <p className="text-gray-500">average data accuracy</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-4xl font-bold">2X</div>
                    <p className="text-gray-500">average conversion improvement</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-4xl font-bold">80%</div>
                    <p className="text-gray-500">reduction in list building time</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-gray-500">
          © 2024 OutboundIntel. All rights reserved. Precision audience intelligence for cold email agencies.
        </p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Terms of Service
          </Link>
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}